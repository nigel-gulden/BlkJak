# GuiWeek1Puzzle
The base code for the puzzle given on week 1 in CST 238 GUI (Oregon Institute of Technology).
